import { combineReducers } from 'redux';
import Customizer from './customizer/reducer';

const reducers = combineReducers({
    Customizer
});

export default reducers;